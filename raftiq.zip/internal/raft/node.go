package raft

import (
	"context"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"sync"
	"time"

	"github.com/sanchar127/raftiq/internal/model"
	"github.com/sanchar127/raftiq/internal/storage"
)

const DefaultRPCTimeout = 2 * time.Second

type RaftNode struct {
	mu      sync.RWMutex
	applyMu sync.Mutex

	runMu   sync.Mutex
	running bool
	stopCh  chan struct{}
	doneCh  chan struct{}

	id     NodeID
	state  State
	log    *Log
	logger *slog.Logger

	transport Transport
	peerIDs   []NodeID

	metrics Metrics

	electionStartedAt time.Time

	applyCh chan LogEntry

	storage storage.Storage

	snapshotRestore func(model.Snapshot) error

	electionElapsed     int
	electionTimeout     int
	electionInFlight    bool
	storageWriteBlocked bool

	heartbeatElapsed int
	heartbeatTimeout int

	tickInterval time.Duration
	rpcTimeout   time.Duration
}

func NewRaftNode(id NodeID) *RaftNode {
	node, err := NewRaftNodeWithStorage(id, storage.NewMemoryStorage())
	if err != nil {
		panic(err)
	}

	return node
}

// SetPeers is retained as a compatibility helper for existing tests.
//
// New production code should use SetTransport so the Raft core depends
// only on the Transport abstraction rather than an in-process Peer.
func (n *RaftNode) SetPeers(peers []Peer) {
	transport := NewLocalTransport()
	peerIDs := make([]NodeID, 0, len(peers))

	for _, peer := range peers {
		if peer == nil {
			continue
		}

		if err := transport.AddPeer(peer); err != nil {
			continue
		}

		peerIDs = append(peerIDs, peer.ID())
	}

	n.mu.Lock()
	n.transport = transport
	n.peerIDs = peerIDs
	n.mu.Unlock()

	n.getLogger().Debug(
		"raft peers configured",
		"peer_count", len(peerIDs),
	)
}

func (n *RaftNode) SetTransport(
	transport Transport,
	peerIDs []NodeID,
) error {
	if transport == nil {
		return errors.New("raft transport is required")
	}

	ids := append([]NodeID(nil), peerIDs...)

	n.mu.Lock()
	n.transport = transport
	n.peerIDs = ids
	n.mu.Unlock()

	n.getLogger().Debug(
		"raft transport configured",
		"peer_count", len(ids),
	)

	return nil
}

func (n *RaftNode) RegisterPeer(peerID NodeID) error {
	if peerID == "" {
		return errors.New("raft peer ID is required")
	}

	n.mu.Lock()
	defer n.mu.Unlock()

	if peerID == n.id {
		return fmt.Errorf("cannot register self as peer")
	}

	for _, existingID := range n.peerIDs {
		if existingID == peerID {
			return fmt.Errorf("raft peer %s already registered", peerID)
		}
	}

	n.peerIDs = append(n.peerIDs, peerID)

	return nil
}

func (n *RaftNode) BootstrapMembership() error {
	logger := n.getLogger()

	n.mu.Lock()

	// A persisted membership is authoritative. Never overwrite it
	// from the current transport topology.
	if len(n.state.Persistent.Membership.Current.Voters) > 0 ||
		n.state.Persistent.Membership.Joint != nil {
		n.mu.Unlock()
		return nil
	}

	voters := make([]NodeID, 0, len(n.peerIDs)+1)
	seen := make(map[NodeID]struct{}, len(n.peerIDs)+1)

	addVoter := func(id NodeID) {
		if id == "" {
			return
		}
		if _, exists := seen[id]; exists {
			return
		}
		seen[id] = struct{}{}
		voters = append(voters, id)
	}

	addVoter(n.id)
	for _, peerID := range n.peerIDs {
		addVoter(peerID)
	}

	if len(voters) == 0 {
		n.mu.Unlock()
		return errors.New("raft membership cannot be bootstrapped without voters")
	}

	n.state.Persistent.Membership = model.Membership{
		Current: model.Configuration{
			Voters: voters,
		},
	}

	if err := n.persistStateLocked(); err != nil {
		n.mu.Unlock()
		return fmt.Errorf("bootstrap membership: %w", err)
	}

	n.mu.Unlock()

	logger.Info(
		"raft membership bootstrapped",
		"voters", voters,
	)

	return nil
}

func (n *RaftNode) transportSnapshot() (Transport, []NodeID) {
	n.mu.RLock()
	defer n.mu.RUnlock()

	return n.transport, append([]NodeID(nil), n.peerIDs...)
}

func (n *RaftNode) ID() NodeID {
	n.mu.RLock()
	defer n.mu.RUnlock()

	return n.id
}

func (n *RaftNode) State() State {
	n.mu.RLock()
	defer n.mu.RUnlock()

	return n.state
}

func (n *RaftNode) Log() *Log {
	n.mu.RLock()
	defer n.mu.RUnlock()

	return n.log
}

func (n *RaftNode) becomeFollower(term Term) error {
	n.mu.Lock()
	defer n.mu.Unlock()

	return n.becomeFollowerLocked(term)
}

func (n *RaftNode) becomeFollowerLocked(term Term) error {
	n.state.Role = Follower
	n.state.Persistent.CurrentTerm = term
	n.state.Persistent.VotedFor = ""
	n.state.LeaderID = ""
	n.electionElapsed = 0

	if err := n.persistStateLocked(); err != nil {
		return fmt.Errorf(
			"persist follower transition: %w",
			err,
		)
	}

	n.updateStateMetricsLocked()

	return nil
}

func (n *RaftNode) stepDownForStorageFailureLocked() {
	n.state.Role = Follower
	n.state.LeaderID = ""
	n.storageWriteBlocked = true
	n.electionElapsed = 0

	n.metrics.SetRole(Follower)
}

func (n *RaftNode) initializeReplicationStateLocked(
	peerID NodeID,
) {
	nextIndex := n.log.LastIndex() + 1

	n.state.Leader.NextIndex[peerID] = nextIndex
	n.state.Leader.MatchIndex[peerID] = 0
}

func (n *RaftNode) initializeNewPeerReplicationStateLocked(
	peerID NodeID,
) {
	n.state.Leader.NextIndex[peerID] = 1
	n.state.Leader.MatchIndex[peerID] = 0
}

func (n *RaftNode) becomeLeaderLocked() {
	n.state.Role = Leader
	n.state.LeaderID = n.id
	n.electionElapsed = 0
	n.heartbeatElapsed = 0

	n.finishElectionLocked("won")
	n.metrics.IncLeaderChanges()
	n.updateStateMetricsLocked()

	for _, peerID := range n.peerIDs {
		n.initializeReplicationStateLocked(peerID)
	}
}

func (n *RaftNode) becomeLeader() {
	logger := n.getLogger()

	n.mu.Lock()

	n.becomeLeaderLocked()

	term := n.state.Persistent.CurrentTerm
	peerCount := len(n.peerIDs)

	n.mu.Unlock()

	logger.Info(
		"raft node became leader",
		"term", term,
		"peer_count", peerCount,
	)
}
func (n *RaftNode) Propose(data []byte) (LogIndex, error) {
	n.mu.Lock()

	if n.state.Role != Leader {
		role := n.state.Role
		term := n.state.Persistent.CurrentTerm
		nodeID := n.id

		n.mu.Unlock()

		err := fmt.Errorf(
			"node %s is not the leader",
			nodeID,
		)

		n.getLogger().Debug(
			"raft proposal rejected",
			"role", role,
			"term", term,
			"error", err,
		)

		return 0, err
	}

	index := n.log.LastIndex() + 1

	entry := LogEntry{
		Index: index,
		Term:  n.state.Persistent.CurrentTerm,
		Data:  append([]byte(nil), data...),
	}

	if err := n.storage.AppendEntries([]LogEntry{entry}); err != nil {
		n.mu.Unlock()

		n.getLogger().Error(
			"failed to persist proposed raft entry",
			"index", index,
			"term", entry.Term,
			"error", err,
		)

		return 0, fmt.Errorf(
			"persist proposed entry: %w",
			err,
		)
	}

	if err := n.storage.Sync(); err != nil {
		if errors.Is(err, storage.ErrWALDiskFull) {
			n.stepDownForStorageFailureLocked()

			n.mu.Unlock()

			n.getLogger().Error(
				"raft leader stepped down due to WAL disk full",
				"index", index,
				"term", entry.Term,
				"error", err,
			)

			return 0, fmt.Errorf(
				"storage disk full: %w",
				err,
			)
		}

		n.mu.Unlock()

		n.getLogger().Error(
			"failed to sync proposed raft entry",
			"index", index,
			"term", entry.Term,
			"error", err,
		)

		return 0, fmt.Errorf(
			"sync proposed entry: %w",
			err,
		)
	}

	if err := n.log.Append(entry); err != nil {
		n.mu.Unlock()

		n.getLogger().Error(
			"failed to append proposed entry to raft log",
			"index", index,
			"term", entry.Term,
			"error", err,
		)

		return 0, fmt.Errorf(
			"append proposed entry to raft log: %w",
			err,
		)
	}

	advanced := n.advanceCommitIndexLocked()

	transport := n.transport
	peerIDs := append([]NodeID(nil), n.peerIDs...)
	term := n.state.Persistent.CurrentTerm

	n.mu.Unlock()

	n.getLogger().Debug(
		"raft proposal accepted",
		"index", index,
		"term", term,
		"data_size", len(data),
		"peer_count", len(peerIDs),
		"commit_advanced", advanced,
	)

	if advanced {
		n.applyCommitted()
	}

	if transport == nil {
		return index, nil
	}

	for _, peerID := range peerIDs {
		n.replicateTo(peerID)
	}

	return index, nil
}

func (n *RaftNode) ProposeConfiguration(
	configuration model.Configuration,
) (LogIndex, error) {
	data, err := EncodeConfigurationEntry(configuration)
	if err != nil {
		return 0, fmt.Errorf(
			"encode configuration proposal: %w",
			err,
		)
	}

	return n.Propose(data)
}

func (n *RaftNode) isCandidateLogUpToDate(
	lastLogIndex LogIndex,
	lastLogTerm Term,
) bool {
	localLastTerm := n.log.LastTerm()
	localLastIndex := n.log.LastIndex()

	if lastLogTerm != localLastTerm {
		return lastLogTerm > localLastTerm
	}

	return lastLogIndex >= localLastIndex
}

func (n *RaftNode) recordVote(
	peerID NodeID,
	term Term,
	granted bool,
) bool {
	n.mu.Lock()
	defer n.mu.Unlock()

	if n.state.Role != Candidate {
		return false
	}

	if term != n.state.Persistent.CurrentTerm {
		return false
	}

	if !granted {
		return false
	}

	// Only voters in the active membership can contribute
	// to an election quorum.
	if !membershipIsVoter(
		n.state.Persistent.Membership,
		peerID,
	) {
		return false
	}

	if _, alreadyReceived := n.state.Election.VotesReceived[peerID]; alreadyReceived {
		return false
	}

	n.state.Election.VotesReceived[peerID] = struct{}{}

	return true
}

func majority(clusterSize int) int {
	return clusterSize/2 + 1
}

func (n *RaftNode) hasElectionMajority() bool {
	n.mu.RLock()
	defer n.mu.RUnlock()

	return membershipHasQuorum(
		n.state.Persistent.Membership,
		n.state.Election.VotesReceived,
	)
}

func (n *RaftNode) tryBecomeLeader() bool {
	logger := n.getLogger()

	n.mu.Lock()

	if n.state.Role != Candidate {
		n.mu.Unlock()
		return false
	}

	if !membershipHasQuorum(
		n.state.Persistent.Membership,
		n.state.Election.VotesReceived,
	) {
		n.mu.Unlock()
		return false
	}

	n.becomeLeaderLocked()

	term := n.state.Persistent.CurrentTerm
	votes := len(n.state.Election.VotesReceived)

	n.mu.Unlock()

	logger.Info(
		"raft election won",
		"term", term,
		"votes", votes,
	)

	return true
}

type Peer interface {
	ID() NodeID

	RequestVote(args RequestVoteArgs) RequestVoteReply

	PreVote(args PreVoteArgs) PreVoteReply

	AppendEntries(args AppendEntriesArgs) AppendEntriesReply

	InstallSnapshot(args InstallSnapshotArgs) InstallSnapshotReply
}

func (n *RaftNode) startElection() (Term, error) {
	logger := n.getLogger()

	n.mu.Lock()

	// A node that is not part of the active voting configuration
	// must never start an election.
	if !membershipIsVoter(
		n.state.Persistent.Membership,
		n.id,
	) {
		term := n.state.Persistent.CurrentTerm

		n.mu.Unlock()

		err := fmt.Errorf(
			"election rejected: node %s is not a voter",
			n.id,
		)

		logger.Warn(
			"raft election rejected",
			"node_id", n.id,
			"term", term,
			"reason", "non_voter",
			"error", err,
		)

		return term, err
	}

	// Do not modify persistent election state when storage is
	// known to be unhealthy.
	if n.storageWriteBlocked {
		term := n.state.Persistent.CurrentTerm

		n.mu.Unlock()

		err := errors.New(
			"election blocked: storage write is unhealthy",
		)

		logger.Warn(
			"raft election rejected",
			"term", term,
			"reason", "storage_write_blocked",
			"error", err,
		)

		return term, err
	}

	// Become a candidate and start a new election term.
	n.state.Role = Candidate
	n.state.Persistent.CurrentTerm++
	n.state.Persistent.VotedFor = n.id
	n.state.LeaderID = ""

	n.electionElapsed = 0

	// A candidate votes for itself.
	n.state.Election.VotesReceived = map[NodeID]struct{}{
		n.id: {},
	}

	n.electionStartedAt = time.Now()
	n.metrics.IncElections()

	// Persist the new term and self-vote before sending RequestVote RPCs.
	if err := n.persistStateLocked(); err != nil {
		n.finishElectionLocked("failed")

		term := n.state.Persistent.CurrentTerm

		n.mu.Unlock()

		logger.Error(
			"raft election failed to persist state",
			"term", term,
			"error", err,
		)

		return 0, err
	}

	n.updateStateMetricsLocked()

	term := n.state.Persistent.CurrentTerm
	peerCount := len(n.peerIDs)

	n.mu.Unlock()

	logger.Info(
		"raft election started",
		"term", term,
		"peer_count", peerCount,
	)

	return term, nil
}

func (n *RaftNode) requestVotes() {
	n.mu.RLock()

	// Only an eligible voter can participate as an election candidate.
	if n.state.Role != Candidate ||
		!membershipIsVoter(
			n.state.Persistent.Membership,
			n.id,
		) {
		n.mu.RUnlock()

		n.getLogger().Debug(
			"raft vote requests skipped",
			"node_id", n.id,
			"reason", "not_eligible_candidate",
		)

		return
	}

	term := n.state.Persistent.CurrentTerm
	lastLogIndex := n.log.LastIndex()
	lastLogTerm := n.log.LastTerm()
	transport := n.transport
	peerIDs := append([]NodeID(nil), n.peerIDs...)
	candidateID := n.id

	n.mu.RUnlock()

	if transport == nil {
		n.getLogger().Debug(
			"raft vote requests skipped",
			"term", term,
			"reason", "transport_unavailable",
		)

		return
	}

	args := RequestVoteArgs{
		Term:         term,
		CandidateID:  candidateID,
		LastLogIndex: lastLogIndex,
		LastLogTerm:  lastLogTerm,
	}

	for _, peerID := range peerIDs {
		ctx, cancel := n.rpcContext()

		reply, err := transport.RequestVote(
			ctx,
			peerID,
			args,
		)

		cancel()

		if err != nil {
			n.getLogger().Debug(
				"vote request failed",
				"peer_id", peerID,
				"term", term,
				"error", err,
			)

			continue
		}

		n.handleVoteReply(term, reply)
	}
}

func (n *RaftNode) RequestVote(
	args RequestVoteArgs,
) (reply RequestVoteReply) {
	logger := n.getLogger()

	n.mu.Lock()
	defer n.mu.Unlock()

	defer func() {
		n.metrics.IncVoteRequests()

		if reply.VoteGranted {
			n.metrics.IncVotesGranted()
		}
	}()

	reply = RequestVoteReply{
		Term:    n.state.Persistent.CurrentTerm,
		VoterID: n.id,
	}

	// Reject requests from an older term.
	if args.Term < n.state.Persistent.CurrentTerm {
		logger.Debug(
			"vote denied",
			"candidate_id", args.CandidateID,
			"request_term", args.Term,
			"current_term", n.state.Persistent.CurrentTerm,
			"reason", "stale_term",
		)

		return reply
	}

	// A higher-term request advances our term and makes us a follower.
	if args.Term > n.state.Persistent.CurrentTerm {
		n.state.Persistent.CurrentTerm = args.Term
		n.state.Role = Follower
		n.state.Persistent.VotedFor = ""
		n.state.LeaderID = ""

		if err := n.persistStateLocked(); err != nil {
			reply.Term = n.state.Persistent.CurrentTerm

			logger.Error(
				"failed to persist higher-term vote state",
				"candidate_id", args.CandidateID,
				"term", args.Term,
				"error", err,
			)

			return reply
		}

		n.updateStateMetricsLocked()
	}

	reply.Term = n.state.Persistent.CurrentTerm

	// Only nodes in the active voting configuration can
	// participate as election candidates.
	if !membershipIsVoter(
		n.state.Persistent.Membership,
		args.CandidateID,
	) {
		logger.Debug(
			"vote denied",
			"candidate_id", args.CandidateID,
			"request_term", args.Term,
			"current_term", n.state.Persistent.CurrentTerm,
			"reason", "candidate_not_voter",
		)

		return reply
	}

	// We can vote only once per term, unless we already voted
	// for this same candidate.
	if n.state.Persistent.VotedFor != "" &&
		n.state.Persistent.VotedFor != args.CandidateID {
		logger.Debug(
			"vote denied",
			"candidate_id", args.CandidateID,
			"request_term", args.Term,
			"current_term", n.state.Persistent.CurrentTerm,
			"reason", "already_voted",
			"voted_for", n.state.Persistent.VotedFor,
		)

		return reply
	}

	// Candidate's log must be at least as up-to-date as ours.
	if !n.isCandidateLogUpToDate(
		args.LastLogIndex,
		args.LastLogTerm,
	) {
		logger.Debug(
			"vote denied",
			"candidate_id", args.CandidateID,
			"request_term", args.Term,
			"current_term", n.state.Persistent.CurrentTerm,
			"reason", "candidate_log_outdated",
			"last_log_index", args.LastLogIndex,
			"last_log_term", args.LastLogTerm,
		)

		return reply
	}

	n.state.Persistent.VotedFor = args.CandidateID

	if err := n.persistStateLocked(); err != nil {
		reply.Term = n.state.Persistent.CurrentTerm

		logger.Error(
			"failed to persist vote",
			"candidate_id", args.CandidateID,
			"term", n.state.Persistent.CurrentTerm,
			"error", err,
		)

		return reply
	}

	reply.Term = n.state.Persistent.CurrentTerm
	reply.VoteGranted = true

	n.electionElapsed = 0

	logger.Debug(
		"vote granted",
		"candidate_id", args.CandidateID,
		"term", n.state.Persistent.CurrentTerm,
	)

	return reply
}

func (n *RaftNode) handleVoteReply(
	electionTerm Term,
	reply RequestVoteReply,
) {
	logger := n.getLogger()

	n.mu.Lock()

	if reply.Term > n.state.Persistent.CurrentTerm {
		n.finishElectionLocked("lost")

		n.state.Persistent.CurrentTerm = reply.Term
		n.state.Role = Follower
		n.state.Persistent.VotedFor = ""
		n.state.LeaderID = ""
		n.state.Election.VotesReceived = make(map[NodeID]struct{})

		if err := n.persistStateLocked(); err != nil {
			n.mu.Unlock()

			logger.Error(
				"failed to persist higher-term follower transition",
				"higher_term", reply.Term,
				"error", err,
			)

			return
		}

		n.updateStateMetricsLocked()
		n.mu.Unlock()

		logger.Info(
			"raft election stepped down due to higher term",
			"election_term", electionTerm,
			"higher_term", reply.Term,
		)

		return
	}

	if n.state.Role != Candidate {
		n.mu.Unlock()
		return
	}

	if electionTerm != n.state.Persistent.CurrentTerm {
		n.mu.Unlock()
		return
	}

	if reply.Term != electionTerm {
		n.mu.Unlock()
		return
	}

	if !reply.VoteGranted {
		n.mu.Unlock()

		logger.Debug(
			"vote request rejected",
			"voter_id", reply.VoterID,
			"term", electionTerm,
		)

		return
	}

	// Only voters in the active membership can contribute
	// to the election quorum.
	if !membershipIsVoter(
		n.state.Persistent.Membership,
		reply.VoterID,
	) {
		n.mu.Unlock()

		logger.Debug(
			"vote ignored",
			"voter_id", reply.VoterID,
			"term", electionTerm,
			"reason", "voter_not_in_membership",
		)

		return
	}

	if _, alreadyReceived := n.state.Election.VotesReceived[reply.VoterID]; alreadyReceived {
		n.mu.Unlock()
		return
	}

	n.state.Election.VotesReceived[reply.VoterID] = struct{}{}

	votes := len(n.state.Election.VotesReceived)

	n.mu.Unlock()

	logger.Debug(
		"vote received",
		"voter_id", reply.VoterID,
		"term", electionTerm,
		"votes", votes,
	)
}

func (n *RaftNode) runElection() {
	n.mu.RLock()

	if n.storageWriteBlocked {
		n.mu.RUnlock()

		n.getLogger().Debug(
			"raft election skipped",
			"reason", "storage_write_blocked",
		)

		return
	}

	n.mu.RUnlock()

	if !n.runPreVote() {
		// The PreVote failed, so wait for another complete election
		// timeout before retrying.

		return
	}

	// A valid leader may have contacted us while the PreVote RPCs
	// were in flight. Re-check the election state before incrementing
	// the real Raft term.
	n.mu.RLock()

	role := n.state.Role
	electionElapsed := n.electionElapsed
	electionTimeout := n.electionTimeout
	leaderID := n.state.LeaderID

	n.mu.RUnlock()

	if role == Leader {
		return
	}

	if leaderID != "" && electionElapsed < electionTimeout {
		// We heard from a valid leader while PreVote was running.
		return
	}

	if _, err := n.startElection(); err != nil {
		// If the election could not be persisted, don't immediately
		// spin another election attempt.
		n.resetElectionTimer()
		return
	}

	n.requestVotes()
	n.tryBecomeLeader()
}
func (n *RaftNode) runPreVote() bool {
	n.mu.RLock()

	term := n.state.Persistent.CurrentTerm + 1
	lastLogIndex := n.log.LastIndex()
	lastLogTerm := n.log.LastTerm()
	candidateID := n.id
	transport := n.transport
	peerIDs := append([]NodeID(nil), n.peerIDs...)
	membership := n.state.Persistent.Membership

	n.mu.RUnlock()

	// Only a node in the active voting configuration
	// can participate as an election candidate.
	if !membershipIsVoter(membership, candidateID) {
		n.getLogger().Debug(
			"raft prevote skipped",
			"node_id", candidateID,
			"term", term,
			"reason", "candidate_not_voter",
		)

		return false
	}

	votes := map[NodeID]struct{}{
		candidateID: {},
	}

	// A single-node/current-membership quorum may already be satisfied.
	if membershipHasQuorum(membership, votes) {
		return true
	}

	if transport == nil {
		n.getLogger().Debug(
			"raft prevote skipped",
			"term", term,
			"reason", "transport_unavailable",
		)

		return false
	}

	args := PreVoteArgs{
		Term:         term,
		CandidateID:  candidateID,
		LastLogIndex: lastLogIndex,
		LastLogTerm:  lastLogTerm,
	}

	for _, peerID := range peerIDs {
		ctx, cancel := n.rpcContext()

		reply, err := transport.PreVote(
			ctx,
			peerID,
			args,
		)

		cancel()

		if err != nil {
			n.getLogger().Debug(
				"prevote request failed",
				"peer_id", peerID,
				"term", term,
				"error", err,
			)

			continue
		}

		// PreVote deliberately does not change our persistent term.
		if !reply.VoteGranted {
			continue
		}

		votes[peerID] = struct{}{}

		if membershipHasQuorum(membership, votes) {
			n.getLogger().Debug(
				"raft prevote won",
				"term", term,
				"votes", len(votes),
			)

			return true
		}
	}

	n.getLogger().Debug(
		"raft prevote lost",
		"term", term,
		"votes", len(votes),
	)

	return false
}
func (n *RaftNode) Tick() bool {
	electionDue, heartbeatDue := n.tick()

	if heartbeatDue {
		n.heartbeat()
	}

	return electionDue
}

func (n *RaftNode) SetElectionTimeout(timeout int) {
	n.mu.Lock()
	defer n.mu.Unlock()

	n.electionTimeout = timeout
}

func (n *RaftNode) onElectionTimeout() {
	state := n.State()

	if state.Role == Leader {
		return
	}

	n.getLogger().Debug(
		"raft election timeout reached",
		"term", state.Persistent.CurrentTerm,
		"role", state.Role,
	)

	n.runElection()
}

func (n *RaftNode) resetElectionTimer() {
	n.mu.Lock()
	defer n.mu.Unlock()

	n.electionElapsed = 0
}

func (n *RaftNode) AppendEntries(
	args AppendEntriesArgs,
) (reply AppendEntriesReply) {
	startedAt := time.Now()

	n.mu.Lock()

	defer func() {
		result := "failure"
		if reply.Success {
			result = "success"
		}

		n.metrics.IncAppendEntries(args.LeaderID, result)

		if !reply.Success {
			n.metrics.IncAppendEntriesFailures(args.LeaderID)
		}

		n.metrics.ObserveAppendEntriesDuration(
			args.LeaderID,
			time.Since(startedAt),
		)
	}()

	reply = AppendEntriesReply{
		Term:       n.state.Persistent.CurrentTerm,
		FollowerID: n.id,
	}

	if args.Term < n.state.Persistent.CurrentTerm {
		n.mu.Unlock()

		n.getLogger().Debug(
			"append entries rejected",
			"leader_id", args.LeaderID,
			"request_term", args.Term,
			"current_term", reply.Term,
			"entry_count", len(args.Entries),
			"reason", "stale_term",
		)

		return reply
	}

	if args.Term > n.state.Persistent.CurrentTerm {
		n.state.Persistent.CurrentTerm = args.Term
		n.state.Role = Follower
		n.state.Persistent.VotedFor = ""
		n.state.LeaderID = ""

		if err := n.persistStateLocked(); err != nil {
			n.mu.Unlock()

			n.getLogger().Error(
				"failed to persist higher-term append entries state",
				"leader_id", args.LeaderID,
				"term", args.Term,
				"error", err,
			)

			return reply
		}
	}

	if args.PrevLogIndex > 0 {
		prevEntry, ok := n.log.Get(args.PrevLogIndex)
		if !ok || prevEntry.Term != args.PrevLogTerm {
			n.mu.Unlock()

			n.getLogger().Debug(
				"append entries rejected",
				"leader_id", args.LeaderID,
				"request_term", args.Term,
				"entry_count", len(args.Entries),
				"reason", "log_mismatch",
				"prev_log_index", args.PrevLogIndex,
				"prev_log_term", args.PrevLogTerm,
			)

			return reply
		}
	}

	n.state.Role = Follower
	n.state.LeaderID = args.LeaderID
	n.electionElapsed = 0

	// Synchronize runtime Raft state with observability.
	n.updateStateMetricsLocked()

	firstNew := -1
	replaceFrom := model.LogIndex(0)

	for i, entry := range args.Entries {
		existing, ok := n.log.Get(entry.Index)
		if !ok {
			firstNew = i
			break
		}

		if existing.Term != entry.Term {
			firstNew = i
			replaceFrom = entry.Index
			break
		}
	}

	if firstNew >= 0 {
		newEntries := cloneEntries(args.Entries[firstNew:])

		if replaceFrom > 0 {
			if err := n.storage.ReplaceSuffix(
				replaceFrom,
				newEntries,
			); err != nil {
				n.mu.Unlock()

				n.getLogger().Error(
					"failed to replace raft log suffix",
					"leader_id", args.LeaderID,
					"replace_from", replaceFrom,
					"entry_count", len(newEntries),
					"error", err,
				)

				return reply
			}

			if err := n.storage.Sync(); err != nil {
				n.mu.Unlock()

				n.getLogger().Error(
					"failed to sync replaced raft log suffix",
					"leader_id", args.LeaderID,
					"replace_from", replaceFrom,
					"error", err,
				)

				return reply
			}

			n.log.TruncateFrom(replaceFrom)

			for _, entry := range newEntries {
				if err := n.log.Append(entry); err != nil {
					n.mu.Unlock()

					n.getLogger().Error(
						"failed to append replicated raft entry",
						"leader_id", args.LeaderID,
						"index", entry.Index,
						"error", err,
					)

					return reply
				}
			}
		} else {
			if err := n.storage.AppendEntries(newEntries); err != nil {
				n.mu.Unlock()

				n.getLogger().Error(
					"failed to persist replicated raft entries",
					"leader_id", args.LeaderID,
					"entry_count", len(newEntries),
					"error", err,
				)

				return reply
			}

			if err := n.storage.Sync(); err != nil {
				n.mu.Unlock()

				n.getLogger().Error(
					"failed to sync replicated raft entries",
					"leader_id", args.LeaderID,
					"entry_count", len(newEntries),
					"error", err,
				)

				return reply
			}

			for _, entry := range newEntries {
				if err := n.log.Append(entry); err != nil {
					n.mu.Unlock()

					n.getLogger().Error(
						"failed to append replicated raft entry",
						"leader_id", args.LeaderID,
						"index", entry.Index,
						"error", err,
					)

					return reply
				}
			}
		}
	}

	commitAdvanced := false

	if args.LeaderCommit > n.state.Volatile.CommitIndex {
		lastIndex := n.log.LastIndex()
		oldCommitIndex := n.state.Volatile.CommitIndex

		if args.LeaderCommit < lastIndex {
			n.state.Volatile.CommitIndex = args.LeaderCommit
		} else {
			n.state.Volatile.CommitIndex = lastIndex
		}

		commitAdvanced =
			n.state.Volatile.CommitIndex > oldCommitIndex
	}

	reply.Term = n.state.Persistent.CurrentTerm
	reply.Success = true

	entryCount := len(args.Entries)
	commitIndex := n.state.Volatile.CommitIndex

	n.mu.Unlock()

	if entryCount > 0 {
		n.getLogger().Debug(
			"append entries accepted",
			"leader_id", args.LeaderID,
			"term", reply.Term,
			"entry_count", entryCount,
			"commit_index", commitIndex,
			"commit_advanced", commitAdvanced,
		)
	}

	if commitAdvanced {
		n.applyCommitted()
	}

	return reply
}

func (n *RaftNode) ApplyCh() <-chan LogEntry {
	return n.applyCh
}

func (n *RaftNode) applyConfigurationEntryLocked(
	entry LogEntry,
) error {
	if len(entry.Data) < 6 {
		return fmt.Errorf(
			"configuration entry at index %d is truncated",
			entry.Index,
		)
	}

	entryType := entry.Data[5]

	var nextMembership model.Membership

	switch entryType {
	case configurationEntryTypeStable:
		configuration, err := DecodeConfigurationEntry(entry.Data)
		if err != nil {
			return fmt.Errorf(
				"decode stable configuration entry at index %d: %w",
				entry.Index,
				err,
			)
		}

		nextMembership = model.Membership{
			Current: configuration,
			Joint:   nil,
		}

	case configurationEntryTypeEnterJoint:
		oldConfiguration, newConfiguration, err :=
			DecodeEnterJointConfigurationEntry(entry.Data)
		if err != nil {
			return fmt.Errorf(
				"decode enter-joint configuration entry at index %d: %w",
				entry.Index,
				err,
			)
		}

		nextMembership = model.Membership{
			Current: oldConfiguration,
			Joint: &model.JointConfiguration{
				Old: oldConfiguration,
				New: newConfiguration,
			},
		}

	case configurationEntryTypeLeaveJoint:
		newConfiguration, err :=
			DecodeLeaveJointConfigurationEntry(entry.Data)
		if err != nil {
			return fmt.Errorf(
				"decode leave-joint configuration entry at index %d: %w",
				entry.Index,
				err,
			)
		}

		nextMembership = model.Membership{
			Current: newConfiguration,
			Joint:   nil,
		}

	default:
		return fmt.Errorf(
			"unknown configuration entry type %d at index %d",
			entryType,
			entry.Index,
		)
	}

	nextState := n.state.Persistent
	nextState.Membership = nextMembership

	if err := n.storage.SaveState(nextState); err != nil {
		return fmt.Errorf(
			"persist membership at index %d: %w",
			entry.Index,
			err,
		)
	}

	if err := n.storage.Sync(); err != nil {
		return fmt.Errorf(
			"sync membership at index %d: %w",
			entry.Index,
			err,
		)
	}

	n.state.Persistent.Membership = nextMembership

	// A leader remains active during joint consensus because the
	// old configuration still includes the leader.
	//
	// Once the final stable configuration no longer contains the
	// local node, the leader must step down.
	if n.state.Role == Leader &&
		nextMembership.Joint == nil &&
		!membershipIsVoter(nextMembership, n.id) {
		if err := n.becomeFollowerLocked(
			n.state.Persistent.CurrentTerm,
		); err != nil {
			return fmt.Errorf(
				"step down after membership removal: %w",
				err,
			)
		}
	}

	return nil
}

func (n *RaftNode) applyCommitted() {
	n.applyMu.Lock()
	defer n.applyMu.Unlock()

	for {
		n.mu.Lock()

		if n.state.Volatile.LastApplied >=
			n.state.Volatile.CommitIndex {
			n.mu.Unlock()
			return
		}

		nextIndex := n.state.Volatile.LastApplied + 1

		entry, ok := n.log.Get(nextIndex)
		if !ok {
			n.mu.Unlock()
			return
		}

		if IsConfigurationEntry(entry.Data) {
			if err := n.applyConfigurationEntryLocked(entry); err != nil {
				n.mu.Unlock()

				n.getLogger().Error(
					"failed to apply raft configuration entry",
					"index", entry.Index,
					"term", entry.Term,
					"error", err,
				)

				return
			}

			n.state.Volatile.LastApplied = nextIndex
			n.mu.Unlock()

			continue
		}

		n.mu.Unlock()

		n.applyCh <- entry

		n.mu.Lock()

		if n.state.Volatile.LastApplied < nextIndex {
			n.state.Volatile.LastApplied = nextIndex
		}

		n.mu.Unlock()
	}
}
func (n *RaftNode) buildAppendEntries(
	peerID NodeID,
) (AppendEntriesArgs, bool) {
	n.mu.RLock()
	defer n.mu.RUnlock()

	if n.state.Role != Leader {
		return AppendEntriesArgs{}, false
	}

	nextIndex, ok := n.state.Leader.NextIndex[peerID]
	if !ok {
		return AppendEntriesArgs{}, false
	}

	args := AppendEntriesArgs{
		Term:         n.state.Persistent.CurrentTerm,
		LeaderID:     n.id,
		LeaderCommit: n.state.Volatile.CommitIndex,
	}

	if nextIndex > 1 {
		prevIndex := nextIndex - 1

		prevEntry, ok := n.log.Get(prevIndex)
		if !ok {
			return AppendEntriesArgs{}, false
		}

		args.PrevLogIndex = prevIndex
		args.PrevLogTerm = prevEntry.Term
	}

	for index := nextIndex; index <= n.log.LastIndex(); index++ {
		entry, ok := n.log.Get(index)
		if !ok {
			return AppendEntriesArgs{}, false
		}

		entry.Data = append([]byte(nil), entry.Data...)
		args.Entries = append(args.Entries, entry)
	}

	return args, true
}

func (n *RaftNode) replicateTo(peerID NodeID) {
	for {
		n.mu.RLock()
		transport := n.transport
		n.mu.RUnlock()

		if transport == nil {
			return
		}

		if n.sendInstallSnapshot(peerID) {
			continue
		}

		args, ok := n.buildAppendEntries(peerID)
		if !ok {
			return
		}

		ctx, cancel := n.rpcContext()

		reply, err := transport.AppendEntries(
			ctx,
			peerID,
			args,
		)

		cancel()

		if err != nil {
			n.getLogger().Debug(
				"append entries transport failure",
				"peer_id", peerID,
				"term", args.Term,
				"entry_count", len(args.Entries),
				"error", err,
			)

			return
		}

		n.handleAppendEntriesReply(
			peerID,
			args,
			reply,
		)

		if reply.Success {
			if len(args.Entries) > 0 {
				n.getLogger().Debug(
					"raft entries replicated",
					"peer_id", peerID,
					"term", args.Term,
					"entry_count", len(args.Entries),
					"last_entry_index", args.Entries[len(args.Entries)-1].Index,
				)
			}

			return
		}

		n.mu.RLock()
		role := n.state.Role
		n.mu.RUnlock()

		if role != Leader {
			return
		}
	}
}

func (n *RaftNode) handleAppendEntriesReply(
	peerID NodeID,
	args AppendEntriesArgs,
	reply AppendEntriesReply,
) {
	n.mu.Lock()

	if reply.Term > n.state.Persistent.CurrentTerm {
		n.state.Persistent.CurrentTerm = reply.Term
		n.state.Role = Follower
		n.state.Persistent.VotedFor = ""
		n.state.LeaderID = ""

		if err := n.persistStateLocked(); err != nil {
			n.mu.Unlock()

			n.getLogger().Error(
				"failed to persist higher-term follower transition",
				"peer_id", peerID,
				"higher_term", reply.Term,
				"error", err,
			)

			return
		}
		n.updateStateMetricsLocked()
		n.mu.Unlock()

		n.getLogger().Info(
			"raft leader stepped down after higher term",
			"peer_id", peerID,
			"higher_term", reply.Term,
		)

		return
	}

	if n.state.Role != Leader {
		n.mu.Unlock()
		return
	}

	if args.Term != n.state.Persistent.CurrentTerm {
		n.mu.Unlock()
		return
	}

	if !reply.Success {
		if nextIndex := n.state.Leader.NextIndex[peerID]; nextIndex > 1 {
			n.state.Leader.NextIndex[peerID]--
		}

		nextIndex := n.state.Leader.NextIndex[peerID]

		n.mu.Unlock()

		n.getLogger().Debug(
			"raft log replication rejected",
			"peer_id", peerID,
			"term", args.Term,
			"next_index", nextIndex,
		)

		return
	}

	if len(args.Entries) == 0 {
		n.mu.Unlock()
		return
	}

	lastReplicated :=
		args.Entries[len(args.Entries)-1].Index

	if lastReplicated > n.state.Leader.MatchIndex[peerID] {
		n.state.Leader.MatchIndex[peerID] = lastReplicated
		n.state.Leader.NextIndex[peerID] = lastReplicated + 1
	}

	advanced := n.advanceCommitIndexLocked()
	commitIndex := n.state.Volatile.CommitIndex

	n.mu.Unlock()

	if advanced {
		n.getLogger().Debug(
			"raft commit index advanced",
			"commit_index", commitIndex,
			"peer_id", peerID,
		)

		n.applyCommitted()
	}
}

func (n *RaftNode) advanceCommitIndexLocked() bool {
	if n.state.Role != Leader {
		return false
	}

	oldCommitIndex := n.state.Volatile.CommitIndex
	membership := n.state.Persistent.Membership

	for index := n.state.Volatile.CommitIndex + 1; index <= n.log.LastIndex(); index++ {
		if n.logTerm(index) != n.state.Persistent.CurrentTerm {
			continue
		}

		replicated := map[NodeID]struct{}{
			n.id: {},
		}

		for _, peerID := range n.peerIDs {
			if n.state.Leader.MatchIndex[peerID] >= index {
				replicated[peerID] = struct{}{}
			}
		}

		if membershipHasQuorum(membership, replicated) {
			n.state.Volatile.CommitIndex = index
		}
	}

	return n.state.Volatile.CommitIndex > oldCommitIndex
}

func (n *RaftNode) logTerm(index LogIndex) Term {
	entry, ok := n.log.Get(index)
	if !ok {
		return 0
	}

	return entry.Term
}

func (n *RaftNode) advanceCommitIndex() {
	n.mu.Lock()

	advanced := n.advanceCommitIndexLocked()

	n.mu.Unlock()

	if advanced {
		n.getLogger().Debug(
			"raft commit index advanced",
			"commit_index", n.State().Volatile.CommitIndex,
		)

		n.applyCommitted()
	}
}

func (n *RaftNode) heartbeatDue() bool {
	n.mu.Lock()
	defer n.mu.Unlock()

	if n.state.Role != Leader {
		return false
	}

	n.heartbeatElapsed++

	if n.heartbeatElapsed < n.heartbeatTimeout {
		return false
	}

	n.heartbeatElapsed = 0
	return true
}

func (n *RaftNode) sendHeartbeats() {
	n.mu.RLock()

	if n.state.Role != Leader {
		n.mu.RUnlock()
		return
	}

	peerIDs := append([]NodeID(nil), n.peerIDs...)

	n.mu.RUnlock()

	for _, peerID := range peerIDs {
		go n.replicateTo(peerID)
	}
}

func (n *RaftNode) sendHeartbeat(peerID NodeID) {
	n.mu.RLock()
	transport := n.transport
	n.mu.RUnlock()

	if transport == nil {
		return
	}

	args, ok := n.buildAppendEntries(peerID)
	if !ok {
		return
	}

	if len(args.Entries) > 0 {
		return
	}

	ctx, cancel := n.rpcContext()

	reply, err := transport.AppendEntries(
		ctx,
		peerID,
		args,
	)

	cancel()

	if err != nil {
		n.getLogger().Debug(
			"heartbeat transport failure",
			"peer_id", peerID,
			"term", args.Term,
			"error", err,
		)

		return
	}

	n.handleAppendEntriesReply(
		peerID,
		args,
		reply,
	)
}

func (n *RaftNode) heartbeat() {
	n.mu.RLock()

	if n.state.Role != Leader {
		n.mu.RUnlock()
		return
	}

	peerIDs := append([]NodeID(nil), n.peerIDs...)

	n.mu.RUnlock()

	for _, peerID := range peerIDs {
		n.replicateTo(peerID)
	}
}

func NewRaftNodeWithStorage(
	id NodeID,
	store storage.Storage,
) (*RaftNode, error) {
	if store == nil {
		return nil, fmt.Errorf("storage must not be nil")
	}

	persistentState, err := store.LoadState()
	if err != nil {
		return nil, fmt.Errorf(
			"load persistent state: %w",
			err,
		)
	}

	entries, err := store.LoadEntries()
	if err != nil {
		return nil, fmt.Errorf(
			"load log entries: %w",
			err,
		)
	}

	snapshot, err := store.LoadSnapshot()
	if err != nil {
		return nil, fmt.Errorf(
			"load snapshot: %w",
			err,
		)
	}

	log := NewLog()

	for _, entry := range entries {
		if err := log.Append(entry); err != nil {
			return nil, fmt.Errorf(
				"restore log entry %d: %w",
				entry.Index,
				err,
			)
		}
	}

	commitIndex := LogIndex(0)
	lastApplied := LogIndex(0)

	if snapshot.LastIncludedIndex > 0 {
		if err := log.RestoreSnapshot(snapshot); err != nil {
			return nil, fmt.Errorf(
				"restore snapshot boundary: %w",
				err,
			)
		}

		commitIndex = snapshot.LastIncludedIndex
		lastApplied = snapshot.LastIncludedIndex
	}

	return &RaftNode{
		id:        id,
		storage:   store,
		transport: NewLocalTransport(),
		peerIDs:   make([]NodeID, 0),
		applyCh:   make(chan LogEntry, 100),
		metrics:   NoopMetrics{},
		logger:    discardRaftLogger(),

		state: State{
			Persistent: persistentState,

			Volatile: VolatileState{
				CommitIndex: commitIndex,
				LastApplied: lastApplied,
			},

			Leader: LeaderState{
				NextIndex:  make(map[NodeID]LogIndex),
				MatchIndex: make(map[NodeID]LogIndex),
			},

			Election: ElectionState{
				VotesReceived: make(map[NodeID]struct{}),
			},

			Role:     Follower,
			LeaderID: "",
		},

		log:              log,
		electionTimeout:  10,
		heartbeatTimeout: 1,
		tickInterval:     100 * time.Millisecond,
		rpcTimeout:       DefaultRPCTimeout,
	}, nil
}

func (n *RaftNode) Storage() storage.Storage {
	n.mu.RLock()
	defer n.mu.RUnlock()

	return n.storage
}

func (n *RaftNode) SetRPCTimeout(timeout time.Duration) error {
	if timeout <= 0 {
		return errors.New("raft RPC timeout must be positive")
	}

	n.mu.Lock()
	n.rpcTimeout = timeout
	n.mu.Unlock()

	return nil
}

func (n *RaftNode) rpcContext() (context.Context, context.CancelFunc) {
	n.mu.RLock()
	timeout := n.rpcTimeout
	n.mu.RUnlock()

	if timeout <= 0 {
		timeout = DefaultRPCTimeout
	}

	return context.WithTimeout(
		context.Background(),
		timeout,
	)
}

func (n *RaftNode) persistStateLocked() error {
	if err := n.storage.SaveState(n.state.Persistent); err != nil {
		return fmt.Errorf(
			"save persistent state: %w",
			err,
		)
	}

	if err := n.storage.Sync(); err != nil {
		return fmt.Errorf(
			"sync persistent state: %w",
			err,
		)
	}

	return nil
}

func (n *RaftNode) Start() error {
	n.runMu.Lock()
	defer n.runMu.Unlock()

	if n.running {
		err := fmt.Errorf(
			"raft node %s is already running",
			n.id,
		)

		n.getLogger().Warn(
			"raft node start rejected",
			"error", err,
		)

		return err
	}

	n.stopCh = make(chan struct{})
	n.doneCh = make(chan struct{})
	n.running = true

	go n.run()

	n.getLogger().Info(
		"raft node started",
		"tick_interval", n.tickInterval.String(),
		"election_timeout", n.electionTimeout,
		"heartbeat_timeout", n.heartbeatTimeout,
	)

	return nil
}

func (n *RaftNode) run() {
	defer close(n.doneCh)

	ticker := time.NewTicker(n.tickInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			n.runTick()

		case <-n.stopCh:
			return
		}
	}
}

func (n *RaftNode) runTick() {
	electionDue, heartbeatDue := n.tick()

	if heartbeatDue {
		go n.heartbeat()
	}

	if electionDue {
		n.startElectionIfNeeded()
	}
}

func (n *RaftNode) startElectionIfNeeded() {
	n.runMu.Lock()

	if n.electionInFlight {
		n.runMu.Unlock()
		return
	}

	n.electionInFlight = true

	n.runMu.Unlock()

	go func() {
		defer func() {
			n.runMu.Lock()
			n.electionInFlight = false
			n.runMu.Unlock()
		}()

		n.runElection()
	}()
}

func (n *RaftNode) Stop() {
	n.runMu.Lock()

	if !n.running {
		n.runMu.Unlock()
		return
	}

	close(n.stopCh)
	doneCh := n.doneCh
	n.running = false

	n.runMu.Unlock()

	<-doneCh

	n.getLogger().Info(
		"raft node stopped",
	)
}

func (n *RaftNode) tick() (electionDue, heartbeatDue bool) {
	n.mu.Lock()
	defer n.mu.Unlock()

	if n.state.Role == Leader {
		n.heartbeatElapsed++

		if n.heartbeatElapsed >= n.heartbeatTimeout {
			n.heartbeatElapsed = 0
			heartbeatDue = true
		}

		return false, heartbeatDue
	}

	n.electionElapsed++

	// Do not reset electionElapsed here.
	//
	// PreVote needs to be able to observe that the election timer
	// actually expired. The timer is reset when:
	//   - a valid AppendEntries is received,
	//   - a vote is granted,
	//   - an actual election starts, or
	//   - a failed PreVote attempt is completed.
	if n.electionElapsed >= n.electionTimeout {
		electionDue = true
	}

	return electionDue, false
}

func (n *RaftNode) WaitApplied(
	ctx context.Context,
	index LogIndex,
) error {
	ticker := time.NewTicker(5 * time.Millisecond)
	defer ticker.Stop()

	for {
		n.mu.RLock()
		applied := n.state.Volatile.LastApplied >= n.state.Volatile.CommitIndex
		if applied {
			n.mu.RUnlock()
			return nil
		}
		n.mu.RUnlock()

		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-ticker.C:
		}
	}
}

func (n *RaftNode) CreateSnapshot(
	index LogIndex,
	data []byte,
) error {
	logger := n.getLogger()

	n.mu.Lock()

	if index > n.state.Volatile.LastApplied {
		err := fmt.Errorf(
			"cannot snapshot unapplied index %d: last applied %d",
			index,
			n.state.Volatile.LastApplied,
		)

		lastApplied := n.state.Volatile.LastApplied

		n.mu.Unlock()

		logger.Warn(
			"snapshot creation rejected",
			"index", index,
			"last_applied", lastApplied,
			"error", err,
		)

		return err
	}

	if index > n.state.Volatile.CommitIndex {
		err := fmt.Errorf(
			"cannot snapshot uncommitted index %d: commit index %d",
			index,
			n.state.Volatile.CommitIndex,
		)

		commitIndex := n.state.Volatile.CommitIndex

		n.mu.Unlock()

		logger.Warn(
			"snapshot creation rejected",
			"index", index,
			"commit_index", commitIndex,
			"error", err,
		)

		return err
	}

	if index == 0 {
		err := fmt.Errorf("cannot snapshot index 0")

		n.mu.Unlock()

		logger.Warn(
			"snapshot creation rejected",
			"index", index,
			"error", err,
		)

		return err
	}

	entry, ok := n.log.Get(index)
	if !ok {
		err := fmt.Errorf(
			"cannot snapshot missing log index %d",
			index,
		)

		n.mu.Unlock()

		logger.Warn(
			"snapshot creation rejected",
			"index", index,
			"error", err,
		)

		return err
	}

	snapshot := model.Snapshot{
		LastIncludedIndex: index,
		LastIncludedTerm:  entry.Term,
		Data:              append([]byte(nil), data...),
	}

	if err := n.storage.SaveSnapshot(snapshot); err != nil {
		wrappedErr := fmt.Errorf(
			"save snapshot: %w",
			err,
		)

		n.mu.Unlock()

		logger.Error(
			"failed to persist snapshot",
			"last_included_index", index,
			"last_included_term", entry.Term,
			"error", wrappedErr,
		)

		return wrappedErr
	}

	if err := n.storage.Sync(); err != nil {
		wrappedErr := fmt.Errorf(
			"sync snapshot: %w",
			err,
		)

		n.mu.Unlock()

		logger.Error(
			"failed to sync snapshot",
			"last_included_index", index,
			"last_included_term", entry.Term,
			"error", wrappedErr,
		)

		return wrappedErr
	}

	if err := n.log.Compact(snapshot); err != nil {
		wrappedErr := fmt.Errorf(
			"compact log after snapshot: %w",
			err,
		)

		n.mu.Unlock()

		logger.Error(
			"failed to compact raft log after snapshot",
			"last_included_index", index,
			"last_included_term", entry.Term,
			"error", wrappedErr,
		)

		return wrappedErr
	}

	n.mu.Unlock()

	logger.Info(
		"raft snapshot created",
		"last_included_index", index,
		"last_included_term", entry.Term,
		"snapshot_size", len(data),
	)

	return nil
}

func (n *RaftNode) Snapshot() (model.Snapshot, error) {
	n.mu.RLock()
	defer n.mu.RUnlock()

	snapshot, err := n.storage.LoadSnapshot()
	if err != nil {
		return model.Snapshot{}, fmt.Errorf(
			"load snapshot: %w",
			err,
		)
	}

	snapshot.Data = append([]byte(nil), snapshot.Data...)

	return snapshot, nil
}

func (n *RaftNode) SetSnapshotRestore(
	restore func(model.Snapshot) error,
) {
	n.mu.Lock()
	defer n.mu.Unlock()

	n.snapshotRestore = restore
}

func (n *RaftNode) InstallSnapshot(
	args InstallSnapshotArgs,
) InstallSnapshotReply {
	logger := n.getLogger()

	n.mu.Lock()

	reply := InstallSnapshotReply{
		Term:       n.state.Persistent.CurrentTerm,
		FollowerID: n.id,
	}

	if args.Term < n.state.Persistent.CurrentTerm {
		n.mu.Unlock()

		logger.Debug(
			"snapshot rejected",
			"leader_id", args.LeaderID,
			"request_term", args.Term,
			"current_term", reply.Term,
			"reason", "stale_term",
		)

		return reply
	}

	if args.Term > n.state.Persistent.CurrentTerm {
		n.state.Persistent.CurrentTerm = args.Term
		n.state.Persistent.VotedFor = ""

		if err := n.persistStateLocked(); err != nil {
			n.mu.Unlock()

			logger.Error(
				"failed to persist term from snapshot",
				"leader_id", args.LeaderID,
				"term", args.Term,
				"error", err,
			)

			return reply
		}
	}

	n.state.Role = Follower
	n.state.LeaderID = args.LeaderID
	n.electionElapsed = 0
	n.updateStateMetricsLocked()

	reply.Term = n.state.Persistent.CurrentTerm

	if args.LastIncludedIndex <= n.log.LastIncludedIndex() {
		reply.Success = true
		n.mu.Unlock()

		logger.Debug(
			"snapshot already installed",
			"leader_id", args.LeaderID,
			"last_included_index", args.LastIncludedIndex,
		)

		return reply
	}

	snapshot := model.Snapshot{
		LastIncludedIndex: args.LastIncludedIndex,
		LastIncludedTerm:  args.LastIncludedTerm,
		Data:              append([]byte(nil), args.Data...),
	}

	if err := n.storage.SaveSnapshot(snapshot); err != nil {
		n.mu.Unlock()

		logger.Error(
			"failed to persist installed snapshot",
			"leader_id", args.LeaderID,
			"last_included_index", args.LastIncludedIndex,
			"error", err,
		)

		return reply
	}

	if err := n.storage.Sync(); err != nil {
		n.mu.Unlock()

		logger.Error(
			"failed to sync installed snapshot",
			"leader_id", args.LeaderID,
			"last_included_index", args.LastIncludedIndex,
			"error", err,
		)

		return reply
	}

	restore := n.snapshotRestore

	n.mu.Unlock()

	if restore != nil {
		if err := restore(snapshot); err != nil {
			logger.Error(
				"failed to restore state machine from snapshot",
				"leader_id", args.LeaderID,
				"last_included_index", args.LastIncludedIndex,
				"error", err,
			)

			return reply
		}
	}

	n.mu.Lock()

	if err := n.log.RestoreSnapshot(snapshot); err != nil {
		n.mu.Unlock()

		logger.Error(
			"failed to restore raft log snapshot boundary",
			"last_included_index", args.LastIncludedIndex,
			"error", err,
		)

		return reply
	}

	if n.state.Volatile.CommitIndex <
		snapshot.LastIncludedIndex {
		n.state.Volatile.CommitIndex =
			snapshot.LastIncludedIndex
	}

	if n.state.Volatile.LastApplied <
		snapshot.LastIncludedIndex {
		n.state.Volatile.LastApplied =
			snapshot.LastIncludedIndex
	}

	reply.Term = n.state.Persistent.CurrentTerm
	reply.Success = true

	n.mu.Unlock()

	logger.Info(
		"raft snapshot installed",
		"leader_id", args.LeaderID,
		"term", args.Term,
		"last_included_index", args.LastIncludedIndex,
		"last_included_term", args.LastIncludedTerm,
		"snapshot_size", len(args.Data),
	)

	return reply
}

func (n *RaftNode) buildInstallSnapshot(
	peerID NodeID,
) (InstallSnapshotArgs, bool) {
	n.mu.RLock()
	defer n.mu.RUnlock()

	if n.state.Role != Leader {
		return InstallSnapshotArgs{}, false
	}

	nextIndex, ok := n.state.Leader.NextIndex[peerID]
	if !ok {
		return InstallSnapshotArgs{}, false
	}

	snapshot, err := n.storage.LoadSnapshot()
	if err != nil {
		return InstallSnapshotArgs{}, false
	}

	if snapshot.LastIncludedIndex == 0 {
		return InstallSnapshotArgs{}, false
	}

	if nextIndex > snapshot.LastIncludedIndex {
		return InstallSnapshotArgs{}, false
	}

	return InstallSnapshotArgs{
		Term:              n.state.Persistent.CurrentTerm,
		LeaderID:          n.id,
		LastIncludedIndex: snapshot.LastIncludedIndex,
		LastIncludedTerm:  snapshot.LastIncludedTerm,
		Data:              append([]byte(nil), snapshot.Data...),
	}, true
}

func (n *RaftNode) handleInstallSnapshotReply(
	peerID NodeID,
	args InstallSnapshotArgs,
	reply InstallSnapshotReply,
) {
	n.mu.Lock()

	if reply.Term > n.state.Persistent.CurrentTerm {
		n.state.Persistent.CurrentTerm = reply.Term
		n.state.Role = Follower
		n.state.Persistent.VotedFor = ""
		n.state.LeaderID = ""

		if err := n.persistStateLocked(); err != nil {
			n.mu.Unlock()

			n.getLogger().Error(
				"failed to persist higher-term follower transition",
				"peer_id", peerID,
				"higher_term", reply.Term,
				"error", err,
			)

			return
		}
		n.updateStateMetricsLocked()
		n.mu.Unlock()

		n.getLogger().Info(
			"raft leader stepped down after higher-term snapshot reply",
			"peer_id", peerID,
			"higher_term", reply.Term,
		)

		return
	}

	if n.state.Role != Leader {
		n.mu.Unlock()
		return
	}

	if args.Term != n.state.Persistent.CurrentTerm {
		n.mu.Unlock()
		return
	}

	if !reply.Success {
		n.mu.Unlock()

		n.getLogger().Debug(
			"snapshot replication rejected",
			"peer_id", peerID,
			"term", args.Term,
			"last_included_index", args.LastIncludedIndex,
		)

		return
	}

	if args.LastIncludedIndex >
		n.state.Leader.MatchIndex[peerID] {
		n.state.Leader.MatchIndex[peerID] =
			args.LastIncludedIndex
	}

	nextIndex := args.LastIncludedIndex + 1

	if nextIndex > n.state.Leader.NextIndex[peerID] {
		n.state.Leader.NextIndex[peerID] = nextIndex
	}

	advanced := n.advanceCommitIndexLocked()

	n.mu.Unlock()

	n.getLogger().Info(
		"raft snapshot replicated",
		"peer_id", peerID,
		"term", args.Term,
		"last_included_index", args.LastIncludedIndex,
	)

	if advanced {
		n.applyCommitted()
	}
}

func (n *RaftNode) sendInstallSnapshot(
	peerID NodeID,
) bool {
	n.mu.RLock()
	transport := n.transport
	n.mu.RUnlock()

	if transport == nil {
		return false
	}

	args, ok := n.buildInstallSnapshot(peerID)
	if !ok {
		return false
	}

	ctx, cancel := n.rpcContext()

	reply, err := transport.InstallSnapshot(
		ctx,
		peerID,
		args,
	)

	cancel()

	if err != nil {
		n.getLogger().Debug(
			"snapshot replication transport failure",
			"peer_id", peerID,
			"term", args.Term,
			"last_included_index", args.LastIncludedIndex,
			"error", err,
		)

		return false
	}

	n.handleInstallSnapshotReply(
		peerID,
		args,
		reply,
	)

	return reply.Success
}

func cloneEntries(entries []LogEntry) []LogEntry {
	cloned := make([]LogEntry, len(entries))

	for i, entry := range entries {
		cloned[i] = entry
		cloned[i].Data = append([]byte(nil), entry.Data...)
	}

	return cloned
}

func (n *RaftNode) SetMetrics(metrics Metrics) {
	if metrics == nil {
		metrics = NoopMetrics{}
	}

	n.mu.Lock()
	defer n.mu.Unlock()

	n.metrics = metrics
	n.updateStateMetricsLocked()
}

func (n *RaftNode) updateStateMetricsLocked() {
	n.metrics.SetCurrentTerm(
		n.state.Persistent.CurrentTerm,
	)

	n.metrics.SetRole(
		n.state.Role,
	)

	n.metrics.SetCommitIndex(
		n.state.Volatile.CommitIndex,
	)

	n.metrics.SetLastApplied(
		n.state.Volatile.LastApplied,
	)

	n.metrics.SetLastLogIndex(
		n.log.LastIndex(),
	)

	n.metrics.SetLogSize(
		n.log.Size(),
	)
}

func (n *RaftNode) finishElectionLocked(result string) {
	if n.electionStartedAt.IsZero() {
		return
	}

	n.metrics.ObserveElectionDuration(
		time.Since(n.electionStartedAt),
		result,
	)

	n.electionStartedAt = time.Time{}
}

func discardRaftLogger() *slog.Logger {
	return slog.New(
		slog.NewTextHandler(io.Discard, nil),
	)
}

func (n *RaftNode) getLogger() *slog.Logger {
	n.mu.RLock()
	logger := n.logger
	n.mu.RUnlock()

	if logger == nil {
		return discardRaftLogger()
	}

	return logger
}

func (n *RaftNode) SetLogger(logger *slog.Logger) {
	if logger == nil {
		logger = discardRaftLogger()
	}

	logger = logger.With(
		slog.String("component", "raft"),
		slog.String("node_id", string(n.id)),
	)

	n.mu.Lock()
	n.logger = logger
	n.mu.Unlock()
}

func (n *RaftNode) PreVote(args PreVoteArgs) PreVoteReply {
	n.mu.Lock()
	defer n.mu.Unlock()

	reply := PreVoteReply{
		Term:        n.state.Persistent.CurrentTerm,
		VoterID:     n.id,
		VoteGranted: false,
	}

	// A leader must never grant a PreVote.
	if n.state.Role == Leader {
		return reply
	}

	// Only candidates in the active voting configuration
	// can participate in pre-voting.
	if !membershipIsVoter(
		n.state.Persistent.Membership,
		args.CandidateID,
	) {
		return reply
	}

	// A PreVote never changes persistent term/vote state.
	if args.Term < n.state.Persistent.CurrentTerm {
		return reply
	}

	// If we recently heard from a valid leader, do not allow an
	// isolated/stale candidate to start another election.
	if n.state.LeaderID != "" &&
		n.electionElapsed < n.electionTimeout {
		return reply
	}

	// Candidate's log must be at least as up-to-date as ours.
	if !n.isCandidateLogUpToDate(
		args.LastLogIndex,
		args.LastLogTerm,
	) {
		return reply
	}

	reply.VoteGranted = true
	return reply
}

func (n *RaftNode) ReadIndex(ctx context.Context) (model.LogIndex, error) {
	if ctx == nil {
		return 0, errors.New("raft: ReadIndex context is nil")
	}

	n.mu.RLock()

	if n.state.Role != Leader {
		n.mu.RUnlock()
		return 0, errors.New("raft: not leader")
	}

	term := n.state.Persistent.CurrentTerm
	commitIndex := n.state.Volatile.CommitIndex
	transport := n.transport
	peerIDs := append([]NodeID(nil), n.peerIDs...)
	membership := n.state.Persistent.Membership

	// Raft §8 requires the leader to have committed an entry from
	// its current term before serving linearizable reads.
	hasCommittedInCurrentTerm := false

	if commitIndex > 0 {
		if entry, ok := n.log.Get(commitIndex); ok {
			hasCommittedInCurrentTerm = entry.Term == term
		}
	}

	n.mu.RUnlock()

	if !hasCommittedInCurrentTerm {
		return 0, errors.New(
			"raft: leader has not committed an entry in the current term yet",
		)
	}

	if transport == nil {
		return 0, errors.New("raft: transport is not configured")
	}

	// The leader counts as one acknowledgement.
	acks := map[NodeID]struct{}{
		n.id: {},
	}

	// A single-node cluster, or a configuration where the leader
	// already satisfies the quorum by itself.
	if membershipHasQuorum(membership, acks) {
		return commitIndex, nil
	}

	type result struct {
		peerID NodeID
		reply  AppendEntriesReply
		err    error
	}

	results := make(chan result, len(peerIDs))

	for _, peerID := range peerIDs {
		peerID := peerID

		go func() {
			n.mu.RLock()

			// ReadIndex is only valid while we remain leader in the
			// same term in which the operation started.
			if n.state.Role != Leader ||
				n.state.Persistent.CurrentTerm != term {
				n.mu.RUnlock()

				select {
				case results <- result{
					peerID: peerID,
					err: errors.New(
						"raft: leadership lost before ReadIndex RPC",
					),
				}:
				case <-ctx.Done():
				}

				return
			}

			args := AppendEntriesArgs{
				Term:         term,
				LeaderID:     n.id,
				LeaderCommit: commitIndex,
			}

			nextIndex, ok := n.state.Leader.NextIndex[peerID]
			if !ok {
				n.mu.RUnlock()

				select {
				case results <- result{
					peerID: peerID,
					err: fmt.Errorf(
						"peer %s has no replication state",
						peerID,
					),
				}:
				case <-ctx.Done():
				}

				return
			}

			// Build a heartbeat with the follower's current
			// replication position. No log entries are sent.
			if nextIndex > 1 {
				prevIndex := nextIndex - 1

				prevEntry, ok := n.log.Get(prevIndex)
				if !ok {
					n.mu.RUnlock()

					select {
					case results <- result{
						peerID: peerID,
						err: fmt.Errorf(
							"previous log entry %d for peer %s not found",
							prevIndex,
							peerID,
						),
					}:
					case <-ctx.Done():
					}

					return
				}

				args.PrevLogIndex = prevIndex
				args.PrevLogTerm = prevEntry.Term
			}

			n.mu.RUnlock()

			rpcCtx, cancel := n.rpcContext()
			defer cancel()

			// Make the RPC respect the caller's context as well.
			go func() {
				select {
				case <-ctx.Done():
					cancel()
				case <-rpcCtx.Done():
				}
			}()

			reply, err := transport.AppendEntries(
				rpcCtx,
				peerID,
				args,
			)

			select {
			case results <- result{
				peerID: peerID,
				reply:  reply,
				err:    err,
			}:
			case <-ctx.Done():
			}
		}()
	}

	pending := len(peerIDs)

	for pending > 0 {
		select {
		case <-ctx.Done():
			return 0, ctx.Err()

		case r := <-results:
			pending--

			if r.err != nil {
				continue
			}

			reply := r.reply

			// A higher term proves that this leader is stale.
			if reply.Term > term {
				if err := n.becomeFollower(reply.Term); err != nil {
					return 0, fmt.Errorf(
						"raft: step down during ReadIndex: %w",
						err,
					)
				}

				return 0, errors.New(
					"raft: leadership lost during ReadIndex",
				)
			}

			// Only a successful response from our original term
			// counts toward the quorum.
			if reply.Term != term || !reply.Success {
				continue
			}

			acks[r.peerID] = struct{}{}

			if !membershipHasQuorum(membership, acks) {
				continue
			}

			// Quorum has confirmed that this leader is still
			// communicating in the same term. Re-check leadership
			// before returning the read index.
			n.mu.RLock()

			stillLeader :=
				n.state.Role == Leader &&
					n.state.Persistent.CurrentTerm == term

			safeIndex := n.state.Volatile.CommitIndex

			n.mu.RUnlock()

			if !stillLeader {
				return 0, errors.New(
					"raft: leadership lost during ReadIndex",
				)
			}

			// Never return an index beyond the commit index observed
			// when this ReadIndex operation started.
			if safeIndex > commitIndex {
				safeIndex = commitIndex
			}

			return safeIndex, nil
		}
	}

	return 0, errors.New("raft: ReadIndex quorum unavailable")
}

func (n *RaftNode) catchUpPeer(
	ctx context.Context,
	peerID NodeID,
	targetIndex LogIndex,
) error {
	for {
		n.mu.RLock()

		if n.state.Role != Leader {
			role := n.state.Role
			n.mu.RUnlock()

			return fmt.Errorf(
				"leader lost while catching up peer %s: role=%v",
				peerID,
				role,
			)
		}

		matchIndex := n.state.Leader.MatchIndex[peerID]

		n.mu.RUnlock()

		if matchIndex >= targetIndex {
			return nil
		}

		select {
		case <-ctx.Done():
			return fmt.Errorf(
				"timed out catching up peer %s to index %d: %w",
				peerID,
				targetIndex,
				ctx.Err(),
			)
		default:
		}

		n.replicateTo(peerID)
	}
}

func (n *RaftNode) waitForApplied(
	ctx context.Context,
	targetIndex LogIndex,
) error {
	ticker := time.NewTicker(5 * time.Millisecond)
	defer ticker.Stop()

	for {
		n.mu.RLock()

		lastApplied := n.state.Volatile.LastApplied
		role := n.state.Role

		n.mu.RUnlock()

		if lastApplied >= targetIndex {
			return nil
		}

		if role != Leader {
			return fmt.Errorf(
				"leader lost while waiting for index %d to apply: role=%v",
				targetIndex,
				role,
			)
		}

		select {
		case <-ctx.Done():
			return fmt.Errorf(
				"timed out waiting for index %d to apply: %w",
				targetIndex,
				ctx.Err(),
			)
		case <-ticker.C:
		}
	}
}

func (n *RaftNode) AddMember(
	ctx context.Context,
	peerID NodeID,
) error {
	if peerID == "" {
		return errors.New("raft member ID is required")
	}

	n.mu.Lock()

	if n.state.Role != Leader {
		role := n.state.Role
		n.mu.Unlock()

		return fmt.Errorf(
			"cannot add member %s: node is not leader (role=%v)",
			peerID,
			role,
		)
	}

	if peerID == n.id {
		n.mu.Unlock()

		return fmt.Errorf(
			"cannot add member %s: member is the local node",
			peerID,
		)
	}

	membership := n.state.Persistent.Membership

	if membership.Joint != nil {
		n.mu.Unlock()

		return errors.New(
			"cannot add member while membership is in joint configuration",
		)
	}

	if membershipIsVoter(membership, peerID) {
		n.mu.Unlock()

		return fmt.Errorf(
			"member %s is already a voter",
			peerID,
		)
	}

	registered := false
	for _, existingID := range n.peerIDs {
		if existingID == peerID {
			registered = true
			break
		}
	}

	if !registered {
		n.mu.Unlock()

		return fmt.Errorf(
			"member %s is not registered as a raft peer",
			peerID,
		)
	}

	oldConfiguration := membership.Current

	newVoters := append(
		[]NodeID(nil),
		oldConfiguration.Voters...,
	)
	newVoters = append(newVoters, peerID)

	newConfiguration := model.Configuration{
		Voters: newVoters,
	}

	n.initializeNewPeerReplicationStateLocked(peerID)

	n.mu.Unlock()

	// Capture the current log boundary. The new peer must first catch
	// up with everything that already exists before entering joint
	// consensus.
	n.mu.RLock()
	targetIndex := n.log.LastIndex()
	n.mu.RUnlock()

	if err := n.catchUpPeer(ctx, peerID, targetIndex); err != nil {
		return fmt.Errorf(
			"catch up new member %s: %w",
			peerID,
			err,
		)
	}

	enterJointData, err := EncodeEnterJointConfigurationEntry(
		oldConfiguration,
		newConfiguration,
	)
	if err != nil {
		return fmt.Errorf(
			"encode enter-joint configuration for member %s: %w",
			peerID,
			err,
		)
	}

	enterJointIndex, err := n.Propose(enterJointData)
	if err != nil {
		return fmt.Errorf(
			"propose enter-joint configuration for member %s: %w",
			peerID,
			err,
		)
	}

	if err := n.waitForApplied(ctx, enterJointIndex); err != nil {
		return fmt.Errorf(
			"wait for enter-joint configuration at index %d: %w",
			enterJointIndex,
			err,
		)
	}

	// Propose() may commit EnterJoint after D has already replied to
	// its replication RPC. Send another replication so D receives the
	// updated LeaderCommit and can apply the joint configuration.
	n.replicateTo(peerID)

	n.mu.RLock()
	jointTargetIndex := n.log.LastIndex()
	n.mu.RUnlock()

	if err := n.catchUpPeer(ctx, peerID, jointTargetIndex); err != nil {
		return fmt.Errorf(
			"catch up member %s through joint configuration: %w",
			peerID,
			err,
		)
	}

	leaveJointData, err := EncodeLeaveJointConfigurationEntry(
		newConfiguration,
	)
	if err != nil {
		return fmt.Errorf(
			"encode leave-joint configuration for member %s: %w",
			peerID,
			err,
		)
	}

	leaveJointIndex, err := n.Propose(leaveJointData)
	if err != nil {
		return fmt.Errorf(
			"propose leave-joint configuration for member %s: %w",
			peerID,
			err,
		)
	}

	if err := n.waitForApplied(ctx, leaveJointIndex); err != nil {
		return fmt.Errorf(
			"wait for leave-joint configuration at index %d: %w",
			leaveJointIndex,
			err,
		)
	}

	n.mu.RLock()
	finalMembership := n.state.Persistent.Membership
	n.mu.RUnlock()

	if finalMembership.Joint != nil {
		return fmt.Errorf(
			"member %s added but membership is still joint",
			peerID,
		)
	}

	if !configurationContainsVoter(
		finalMembership.Current,
		peerID,
	) {
		return fmt.Errorf(
			"member %s was not present in final membership",
			peerID,
		)
	}

	return nil
}

func (n *RaftNode) RemoveMember(
	ctx context.Context,
	peerID NodeID,
) error {
	if peerID == "" {
		return errors.New("raft member ID is required")
	}

	n.mu.Lock()

	if n.state.Role != Leader {
		role := n.state.Role
		n.mu.Unlock()

		return fmt.Errorf(
			"cannot remove member %s: node is not leader (role=%v)",
			peerID,
			role,
		)
	}

	membership := n.state.Persistent.Membership

	if membership.Joint != nil {
		n.mu.Unlock()

		return errors.New(
			"cannot remove member while membership is in joint configuration",
		)
	}

	if !membershipIsVoter(membership, peerID) {
		n.mu.Unlock()

		return fmt.Errorf(
			"member %s is not a voter",
			peerID,
		)
	}

	oldConfiguration := membership.Current

	if len(oldConfiguration.Voters) <= 1 {
		n.mu.Unlock()

		return errors.New(
			"cannot remove the last voter",
		)
	}

	newVoters := make([]NodeID, 0, len(oldConfiguration.Voters)-1)

	for _, voterID := range oldConfiguration.Voters {
		if voterID != peerID {
			newVoters = append(newVoters, voterID)
		}
	}

	newConfiguration := model.Configuration{
		Voters: newVoters,
	}

	n.mu.Unlock()

	enterJointData, err := EncodeEnterJointConfigurationEntry(
		oldConfiguration,
		newConfiguration,
	)
	if err != nil {
		return fmt.Errorf(
			"encode enter-joint configuration for member %s: %w",
			peerID,
			err,
		)
	}

	enterJointIndex, err := n.Propose(enterJointData)
	if err != nil {
		return fmt.Errorf(
			"propose enter-joint configuration for member %s: %w",
			peerID,
			err,
		)
	}

	if err := n.waitForApplied(ctx, enterJointIndex); err != nil {
		return fmt.Errorf(
			"wait for enter-joint configuration at index %d: %w",
			enterJointIndex,
			err,
		)
	}

	leaveJointData, err := EncodeLeaveJointConfigurationEntry(
		newConfiguration,
	)
	if err != nil {
		return fmt.Errorf(
			"encode leave-joint configuration for member %s: %w",
			peerID,
			err,
		)
	}

	leaveJointIndex, err := n.Propose(leaveJointData)
	if err != nil {
		return fmt.Errorf(
			"propose leave-joint configuration for member %s: %w",
			peerID,
			err,
		)
	}

	if err := n.waitForApplied(ctx, leaveJointIndex); err != nil {
		return fmt.Errorf(
			"wait for leave-joint configuration at index %d: %w",
			leaveJointIndex,
			err,
		)
	}

	n.mu.RLock()
	finalMembership := n.state.Persistent.Membership
	n.mu.RUnlock()

	if finalMembership.Joint != nil {
		return fmt.Errorf(
			"member %s removed but membership is still joint",
			peerID,
		)
	}

	if configurationContainsVoter(
		finalMembership.Current,
		peerID,
	) {
		return fmt.Errorf(
			"member %s is still present in final membership",
			peerID,
		)
	}

	return nil
}
